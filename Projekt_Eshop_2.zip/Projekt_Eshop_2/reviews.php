<?php session_start();
include "db.php";
include "header.html";
?>

<?php
    $sqlb = "SELECT * FROM Reviews";
    $restultb = $conn->query($sqlb);
    while ($review = $restultb->fetch_assoc()){
        $review_aut = $review["UserID"];
        $sqlc = "SELECT * FROM Users Where UserID = $review_aut";
        $author = $conn->query($sqlc);
        $author_info = $author->fetch_assoc();

        ?>
        <div class="review">
            <h3 class="review-author"><?php echo $author_info["FirstName"] . " " . $author_info["LastName"];?></h3>
            <p class="review-text"><?php echo $review["TextOfReview"];?></p>
            <p class="stars"> 
                <?php
                echo str_repeat("★ ", $review["Stars"]) . str_repeat("☆ ", 5 - $review["Stars"]) ;
                ?>
            </p>
        </div>
        <?php


    }
?>


<!-- vzorová recenze se správnými stylovacími třídami -->
<!--<div class="review">
    <h3 class="review-author">Jan Novák</h3>
    <p class="review-text">Zbozi mi prislo po dvou tydnech. Poskozene...</p>
    <p class="stars"> ★ ★ ☆ ☆ ☆</p>
</div>-->

</body>
</html>